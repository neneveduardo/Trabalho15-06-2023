﻿using Microsoft.EntityFrameworkCore;
namespace Formulario_de_Cadastro.Models
{
    public class Context : DbContext

    {
        public Context(DbContextOptions<Context> opcoes) : base(opcoes)
        {
        }
        public DbSet<DBUsuario> usuario { get; set; }

    }
}
